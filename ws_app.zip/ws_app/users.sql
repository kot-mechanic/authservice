--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.10
-- Dumped by pg_dump version 9.6.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: pic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pic_id_seq OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: pic; Type: TABLE; Schema: public; Owner: authadmin
--

CREATE TABLE public.pic (
    pic_id integer DEFAULT nextval('public.pic_id_seq'::regclass) NOT NULL,
    user_id integer,
    filepath character varying(200),
    ava boolean DEFAULT false NOT NULL
);


ALTER TABLE public.pic OWNER TO authadmin;

--
-- Name: socnet; Type: TABLE; Schema: public; Owner: authadmin
--

CREATE TABLE public.socnet (
    user_id integer,
    vk character varying(20),
    fb character varying(20),
    insta character varying(20),
    telegram character varying(20),
    youtube character varying(20),
    linkedin character varying(20),
    ok character varying(20)
);


ALTER TABLE public.socnet OWNER TO authadmin;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: authadmin
--

CREATE TABLE public.users (
    user_id integer DEFAULT nextval('public.user_id_seq'::regclass) NOT NULL,
    name character varying(100),
    nickname character varying(100),
    mail1 character varying(50),
    mail2 character varying(50),
    phone1 character varying(20),
    phone2 character varying(20),
    password character varying(200)
);


ALTER TABLE public.users OWNER TO authadmin;

--
-- Data for Name: pic; Type: TABLE DATA; Schema: public; Owner: authadmin
--

COPY public.pic (pic_id, user_id, filepath, ava) FROM stdin;
\.


--
-- Name: pic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pic_id_seq', 28, true);


--
-- Data for Name: socnet; Type: TABLE DATA; Schema: public; Owner: authadmin
--

COPY public.socnet (user_id, vk, fb, insta, telegram, youtube, linkedin, ok) FROM stdin;
\.


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_id_seq', 25, true);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: authadmin
--

COPY public.users (user_id, name, nickname, mail1, mail2, phone1, phone2, password) FROM stdin;
\.


--
-- Name: users nickname; Type: CONSTRAINT; Schema: public; Owner: authadmin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT nickname UNIQUE (nickname);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: authadmin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: socnet fk_user_id; Type: FK CONSTRAINT; Schema: public; Owner: authadmin
--

ALTER TABLE ONLY public.socnet
    ADD CONSTRAINT fk_user_id FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: pic fk_user_id; Type: FK CONSTRAINT; Schema: public; Owner: authadmin
--

ALTER TABLE ONLY public.pic
    ADD CONSTRAINT fk_user_id FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: TABLE pic; Type: ACL; Schema: public; Owner: authadmin
--

GRANT ALL ON TABLE public.pic TO postgres;


--
-- Name: TABLE socnet; Type: ACL; Schema: public; Owner: authadmin
--

GRANT ALL ON TABLE public.socnet TO postgres;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: authadmin
--

GRANT ALL ON TABLE public.users TO postgres;


--
-- PostgreSQL database dump complete
--

